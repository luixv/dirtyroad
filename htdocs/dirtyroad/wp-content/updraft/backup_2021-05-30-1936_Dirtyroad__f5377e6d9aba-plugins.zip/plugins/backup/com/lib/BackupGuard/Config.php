<?php

namespace BackupGuard;

class Config
{
	const URL = 'https://backup-guard.com/admin/api/v1';
	const TOKEN_EXPIRES = 3600;
}
