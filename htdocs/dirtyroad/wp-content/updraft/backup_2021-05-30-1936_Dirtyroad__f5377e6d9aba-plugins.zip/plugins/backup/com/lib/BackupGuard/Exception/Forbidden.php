<?php

namespace BackupGuard;

require_once(dirname(__FILE__).'/Exception.php');

class ForbiddenException extends Exception
{

}
