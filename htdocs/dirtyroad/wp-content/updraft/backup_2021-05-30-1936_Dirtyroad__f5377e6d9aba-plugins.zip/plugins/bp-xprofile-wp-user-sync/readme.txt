=== BP xProfile WordPress User Sync ===
Contributors: needle
Donate link: https://www.paypal.me/interactivist
Tags: buddypress, xprofile, profile, sync
Requires at least: 3.5
Tested up to: 5.7
Stable tag: 0.6.7
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Replaces the default BuddyPress xProfile Name field with First Name and Last Name fields and keeps these in sync with WordPress user profile fields.



== Description ==

**IMPORTANT: This plugin is not needed if you have [BuddyPress 8.0.0 or greater](https://bpdevel.wordpress.com/2021/03/24/wordpress-xprofile-field-types/). If you are upgrading to BuddyPress 8.0.0 and already have this plugin installed, please upgrade via FTP/SFTP and then visit this plugin's "Migration Page" to switch to using built-in BuddyPress xProfile Fields.**

The BP xProfile WordPress User Sync plugin is useful when you have a BuddyPress network in which you want to make sure that users enter values for First Name and Last Name rather than rely on the more freeform default Name field that BuddyPress provides.

The plugin replaces the default BuddyPress xProfile Name field with two fields called (surprisingly) First Name and Last Name. These field values are kept in sync with the corresponding WordPress user profile fields as well as the BuddyPress xProfile Name field itself.

### Plugin Updates

**The best way to update this plugin is to replace the folder with the latest version via FTP/SFTP or similar. This avoids the deactivate-reactivate process.**

### Plugin Deactivation

**Please note:** because there is no way to hide xProfile fields, all field definitions associated with this plugin are deleted when it is deactivated. The field data itself is not deleted and the plugin makes an attempt to reconnect the existing data to the new field definitions when it is reactivated. **Always back up your database before deactivating this plugin.**

### Plugin Development

This plugin is no longer in active development.



== Installation ==

1. Extract the plugin archive
1. Upload plugin files to your `/wp-content/plugins/` directory
1. Activate the plugin through the 'Plugins' menu in WordPress



== Changelog ==

= 0.6.7 =

Final release helps migrate Fields to BuddyPress 8.0.0

= 0.6.6 =

Fix sync from WordPress to BuddyPress

= 0.6.5 =

Add translation files

= 0.6.4 =

Fix profile sync when first name and/or last name contain one or more spaces

= 0.6.3 =

Fix profile sync from multisite subsites

= 0.6.2 =

* More detailed plugin update warnings
* Prevent "can_delete" being incorrectly updated

= 0.6.1 =

Damage limitation

= 0.6 =

Broken release :(

= 0.5.3 =

Respect existing excluded fields during xProfile query process

= 0.5.2 =

Pre-filter profile query when BP is sufficiently recent

= 0.5.1 =

Fix translation (props flegmatiq)

= 0.5 =

* Reconnect field data to field definitions when plugin is reactivated
* Hides default name field from Profile Edit admin screen in BP 2.1+

= 0.4.5 =

Allow field substitution in registration form regardless of location

= 0.4.4 =

Update plugin compatibility flags

= 0.4.3 =

Fix warning when BP_Members_Admin object is not present

= 0.4.2 =

Profile queries fixed when editing multiple profile groups - props WIBeditor

= 0.4.1 =

Profile queries fixed when there are multiple profile groups - props WIBeditor

= 0.4 =

Tested compatibility with WP 3.8

= 0.3 =

Compatibility with 'WP FB AutoConnect Premium' and 'CiviCRM WordPress Profile Sync' plugins

= 0.2 =

Initial release

= 0.1 =

Initial commit



== Upgrade Notice ==

= 0.6.7 =

When upgrading this plugin, it is **strongly recommended** that you replace the plugin directory directly. This is preferable because it avoids the deactivate-activate process that happens with the WordPress updater. This will be the final release of this plugin because BuddyPress itself now provides this functionality. Use the Migration Page to convert existing xProfile Fields to those provided by BuddyPress 8.0.0.

= 0.6.6 =

When upgrading this plugin, it is **strongly recommended** that you replace the plugin directory directly. This is preferable because it avoids the deactivate-activate process that happens with the WordPress updater.

= 0.6.5 =

When upgrading this plugin, it is **strongly recommended** that you replace the plugin directory directly. This is preferable because it avoids the deactivate-activate process that happens with the WordPress updater.

= 0.6.4 =

When upgrading this plugin, it is **strongly recommended** that you replace the plugin directory directly. This is preferable because it avoids the deactivate-activate process that happens with the WordPress updater.

= 0.6.3 =

When upgrading this plugin, it's best to simply replace the plugin directory directly. This is preferable to using the WordPress updater because it avoids the deactivate-activate process.
