=== Sitewide Admin Footer Text ===
Contributors:sbrajesh,cosmiccoders
Donate link: http://buddydev.com/donate/
Tags: wpmu,sitewide admin footer,footer,admin,buddypress
Requires at least: Wordpress Mu 2.8
Tested up to: Wordpress Mu 2.8.6
Stable tag: 1.0



Sitewide Admin Footer Text ,allows wordpress mu site administrators to set the footer text to be shown in the admin footer for all users/blogs
== Description ==

If you are a site administrator, you can specify the content of the admin footer from SiteAdmin->Options and It will be shown in the admin footer of all the blogs.It is a beackend branding/enhancement functionality.

== Installation ==
1.Download sitewide-admin-footer-text.zip
2.unzip and upload sitewide-admin-footer-text to  "/wp-content/plugins/".
3. Activate Sitewide Admin Footer Text in the "Plugins" admin panel using the "Activate Site Wide" link.

Or
Use Plugin browser to upload it and activate sitewide.

==Usage==
Login as Site Admin.Go to Dashboard->SiteAdmin->Options.
Look for Sitewide fotter content box and Update it with your own.You can use html there.
Click Save and You are Done.
== Frequently Asked Questions ==

= Will this work on standard WordPress? =

May be,I don't know,As I have not tested it with standard wordpress but tested with wordpress mu/wpmu+buddypress



== Screenshots ==

1. Site Admin Option screenshot-1.png
2. Changed Footer screenshot screenshot-2.png

== Other ==
You can get support here
http://buddydev.com/(http://buddydev.com/ "Your One Stop destination for all the buddypress themes,plugins,tutorials")