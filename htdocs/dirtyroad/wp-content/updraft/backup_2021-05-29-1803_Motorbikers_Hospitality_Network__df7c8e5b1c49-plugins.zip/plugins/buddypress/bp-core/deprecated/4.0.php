<?php
/**
 * Deprecated functions.
 *
 * @deprecated 4.0.0
 */

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

/**
 * Print moment.js config in page footer.
 *
 * @since 2.7.0
 * @since 4.0.0 Deprecated as BP requires WP >= 4.6.
 *
 * @access private
 */
function _bp_core_moment_js_config_footer() {
	_deprecated_function( __FUNCTION__, '4.0' );
}
