<?php
// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

return array(
	0  => array(
		'login' => 'antawn',
		'pass'  => '1234567890',
		'display_name' => 'Antawn Jamison',
		'email' => 'bp.def.data+1@gmail.com',
	),
	1  => array(
		'login' => 'chynna',
		'pass'  => '1234567890',
		'display_name' => 'Chynna Phillips',
		'email' => 'bp.def.data+2@gmail.com',
	),
	2  => array(
		'login' => 'kiki',
		'pass'  => '1234567890',
		'display_name' => 'Kiki Cuyler',
		'email' => 'bp.def.data+3@gmail.com',
	),
	3  => array(
		'login' => 'malivai',
		'pass'  => '1234567890',
		'display_name' => 'MaliVai Washington',
		'email' => 'bp.def.data+4@gmail.com',
	),
	4  => array(
		'login' => 'matraca',
		'pass'  => '1234567890',
		'display_name' => 'Matraca Berg',
		'email' => 'bp.def.data+5@gmail.com',
	),
	5  => array(
		'login' => 'ron',
		'pass'  => '1234567890',
		'display_name' => 'Ron Faucheux',
		'email' => 'bp.def.data+6@gmail.com',
	),
	6  => array(
		'login' => 'michellie',
		'pass'  => '1234567890',
		'display_name' => 'Michellie Jones',
		'email' => 'bp.def.data+7@gmail.com',
	),
	7  => array(
		'login' => 'monta',
		'pass'  => '1234567890',
		'display_name' => 'Monta Ellis',
		'email' => 'bp.def.data+8@gmail.com',
	),
	8  => array(
		'login' => 'picabo',
		'pass'  => '1234567890',
		'display_name' => 'Picabo Street',
		'email' => 'bp.def.data+9@gmail.com',
	),
	9  => array(
		'login' => 'ralph',
		'pass'  => '1234567890',
		'display_name' => 'Ralph Fiennes',
		'email' => 'bp.def.data+10@gmail.com',
	),
	10 => array(
		'login' => 'seamus',
		'pass'  => '1234567890',
		'display_name' => 'Seamus',
		'email' => 'bp.def.data+11@gmail.com',
	),
	11 => array(
		'login' => 'shan',
		'pass'  => '1234567890',
		'display_name' => 'Shan Foster',
		'email' => 'bp.def.data+12@gmail.com',
	),
	12 => array(
		'login' => 'siobhan',
		'pass'  => '1234567890',
		'display_name' => 'Siobhan',
		'email' => 'bp.def.data+13@gmail.com',
	),
	13 => array(
		'login' => 'stephen',
		'pass'  => '1234567890',
		'display_name' => 'Stephen Curry',
		'email' => 'bp.def.data+14@gmail.com',
	),
	14 => array(
		'login' => 'wynonna',
		'pass'  => '1234567890',
		'display_name' => 'Wynonna Judd',
		'email' => 'bp.def.data+15@gmail.com',
	),
	15 => array(
		'login' => 'john',
		'pass'  => '1234567890',
		'display_name' => 'John Caius',
		'email' => 'bp.def.data+16@gmail.com',
	),
	16 => array(
		'login' => 'thomas',
		'pass'  => '1234567890',
		'display_name' => 'Thomas Carew',
		'email' => 'bp.def.data+17@gmail.com',
	),
	17 => array(
		'login' => 'jason',
		'pass'  => '1234567890',
		'display_name' => 'Jason Chaffetz',
		'email' => 'bp.def.data+18@gmail.com',
	),
	18 => array(
		'login' => 'mamah',
		'pass'  => '1234567890',
		'display_name' => 'Mamah Cheney',
		'email' => 'bp.def.data+19@gmail.com',
	),
	19 => array(
		'login' => 'cecelia',
		'pass'  => '1234567890',
		'display_name' => 'Cecelia Cichan ',
		'email' => 'bp.def.data+20@gmail.com',
	),
	20 => array(
		'login' => 'dan',
		'pass'  => '1234567890',
		'display_name' => 'Dan Cortese ',
		'email' => 'bp.def.data+21@gmail.com',
	),
	21 => array(
		'login' => 'vernon',
		'pass'  => '1234567890',
		'display_name' => 'Vernon Dahmer',
		'email' => 'bp.def.data+22@gmail.com',
	),
	22 => array(
		'login' => 'andre',
		'pass'  => '1234567890',
		'display_name' => 'Andre Dubus',
		'email' => 'bp.def.data+23@gmail.com',
	),
	23 => array(
		'login' => 'justin',
		'pass'  => '1234567890',
		'display_name' => 'Justin Duchscherer',
		'email' => 'bp.def.data+24@gmail.com',
	),
	24 => array(
		'login' => 'keir',
		'pass'  => '1234567890',
		'display_name' => 'Keir Dullea ',
		'email' => 'bp.def.data+25@gmail.com',
	),
);
