<?php

/*
 * Features section
 *
 * @see mp_emmet_after_sidebar_features_function()
 * @see mp_emmet_before_sidebar_features_function()
 */

if ( ! function_exists( 'mp_emmet_after_sidebar_features_function' ) ) {

	function mp_emmet_after_sidebar_features_function() {
		return '';
	}

}
if ( ! function_exists( 'mp_emmet_before_sidebar_features_function' ) ) {

	function mp_emmet_before_sidebar_features_function() {
		return '';
	}

}
/*
 * Google map section
 *
 * @see mp_emmet_after_sidebar_googlemap_function()
 * @see mp_emmet_before_sidebar_googlemap_function()
 */

if ( ! function_exists( 'mp_emmet_after_sidebar_googlemap_function' ) ) {

	function mp_emmet_after_sidebar_googlemap_function() {
		return '';
	}

}
if ( ! function_exists( 'mp_emmet_before_sidebar_googlemap_function' ) ) {

	function mp_emmet_before_sidebar_googlemap_function() {
		return '';
	}

}
/*
 * Plan section
 *
 * @see mp_emmet_after_sidebar_plan_function()
 * @see mp_emmet_before_sidebar_plan_function()
 */

if ( ! function_exists( 'mp_emmet_after_sidebar_plan_function' ) ) {

	function mp_emmet_after_sidebar_plan_function() {
		return '';
	}

}
if ( ! function_exists( 'mp_emmet_before_sidebar_plan_function' ) ) {

	function mp_emmet_before_sidebar_plan_function() {
		return '';
	}

}
/*
 * Subscribe section
 *
 * @see mp_emmet_after_sidebar_subscribe_function()
 * @see mp_emmet_before_sidebar_subscribe_function()
 */

if ( ! function_exists( 'mp_emmet_after_sidebar_subscribe_function' ) ) {

	function mp_emmet_after_sidebar_subscribe_function() {
		return '';
	}

}
if ( ! function_exists( 'mp_emmet_before_sidebar_subscribe_function' ) ) {

	function mp_emmet_before_sidebar_subscribe_function() {
		return '';
	}

}
/*
 * Team section
 *
 * @see mp_emmet_after_sidebar_team_function()
 * @see mp_emmet_before_sidebar_team_function()
 */

if ( ! function_exists( 'mp_emmet_after_sidebar_team_function' ) ) {

	function mp_emmet_after_sidebar_team_function() {
		return '';
	}

}
if ( ! function_exists( 'mp_emmet_before_sidebar_team_function' ) ) {

	function mp_emmet_before_sidebar_team_function() {
		return '';
	}

}
/*
 * Testimonials section
 *
 * @see mp_emmet_after_sidebar_testimonials_function()
 * @see mp_emmet_before_sidebar_testimonials_function()
 */

if ( ! function_exists( 'mp_emmet_after_sidebar_testimonials_function' ) ) {

	function mp_emmet_after_sidebar_testimonials_function() {
		return '';
	}

}
if ( ! function_exists( 'mp_emmet_before_sidebar_testimonials_function' ) ) {

	function mp_emmet_before_sidebar_testimonials_function() {
		return '';
	}

}
