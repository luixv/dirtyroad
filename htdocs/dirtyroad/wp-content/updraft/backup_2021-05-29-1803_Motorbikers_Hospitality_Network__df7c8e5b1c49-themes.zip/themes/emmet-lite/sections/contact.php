<?php
/*
 * Contact us section 
 */

if (has_action('mp_emmet_contact_form')) {
    do_action('mp_emmet_contact_form');
}